from rest_framework import serializers
from .models import Album, Artist, Genre, Review


class ArtistBasicSerializer(serializers.ModelSerializer):
    class Meta:
        model = Artist
        fields = "__all__"


class ArtistDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = Artist
        fields = "__all__"


class GenreSerializer(serializers.ModelSerializer):
    class Meta:
        model = Genre
        fields = ["id", "name"]


class ReviewSerializer(serializers.ModelSerializer):
    class Meta:
        model = Review
        fields = ["id", "content", "rating", "created_at"]


class AlbumListSerializer(serializers.ModelSerializer):
    artist = ArtistBasicSerializer(read_only=True)

    class Meta:
        model = Album
        fields = "__all__"


class AlbumDetailSerializer(serializers.ModelSerializer):
    artist = ArtistBasicSerializer(read_only=True)
    genre = GenreSerializer(read_only=True)

    class Meta:
        model = Album
        fields = ["id", "title", "artist", "genre", "release_date", "description"]


class AlbumCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Album
        fields = ["title", "artist", "genre", "release_date", "description"]
